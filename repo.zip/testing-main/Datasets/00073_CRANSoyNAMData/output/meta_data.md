# SoyNAM: Soybean Nested Association Mapping Dataset

This publication discusses the Genomic and multi-environmental soybean data. Soybean Nested
Association Mapping (SoyNAM) project dataset funded by the United Soybean Board
(USB). BLUP function formats data for genome-wide prediction and association analysis.
It contains  genotypes and  markers.

Title: SoyNAM: Soybean Nested Association Mapping Dataset
Scientific name: 
DOI: https://doi.org/10.32614/CRAN.package.SoyNAM
Has phenotype 

