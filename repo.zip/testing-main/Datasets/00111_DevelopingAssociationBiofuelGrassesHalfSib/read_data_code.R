
library(data.table)

# Get geno
geno <- fread('data/pop2_halfsib_0.05_0.5_min5_h_e3/HapMap.hmp.txt')
dim(geno)
