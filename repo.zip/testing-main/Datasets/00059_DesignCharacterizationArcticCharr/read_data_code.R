library(data.table)

# Get geno
geno <- fread('pone.0215008.s001.tsv')
dim(geno)
