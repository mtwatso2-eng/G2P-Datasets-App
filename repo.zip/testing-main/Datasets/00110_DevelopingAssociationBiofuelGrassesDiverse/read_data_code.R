
library(data.table)

# Get geno
geno <- fread('data/asso_0.05_0.5_min5_e3/HapMap.hmp.txt')
dim(geno)

