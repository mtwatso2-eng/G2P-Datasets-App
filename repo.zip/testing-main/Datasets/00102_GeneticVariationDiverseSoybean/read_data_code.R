library(vcfR)

# Get geno
geno = read.vcfR('glyma.Wm82.gnm2_.div_.Valliyodan_Brown_2021.USB481.vcf.gz')
dim(geno)

