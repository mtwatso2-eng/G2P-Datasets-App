library(data.table)

# Get geno
geno <- fread('Genotyping_17mar14_Atlantic_FinalReport.txt')
dim(geno)