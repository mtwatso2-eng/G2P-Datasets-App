library(data.table)

# Get geno
geno <- fread('Genotypes_pureind.txt')
dim(geno)