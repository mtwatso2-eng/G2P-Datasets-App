# Get geno
geno <- read.csv('Tetraploid_SNPdata.csv')
dim(geno)

# Get pheno
pheno <- read.csv('Tetraploid_phenotypic_data.csv')
head(pheno)
