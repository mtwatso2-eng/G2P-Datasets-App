# Get geno
geno <- read.csv('Pop_Int_SNPdata.csv')
dim(geno)

# Get pheno
pheno <- read.csv('Pop_Int_PHENOdata.csv')
head(pheno)
